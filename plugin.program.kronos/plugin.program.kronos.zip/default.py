import xbmcgui
import xbmcplugin
import sys

handle = int(sys.argv[1])
xbmcgui.Dialog().notification("Kronos", "Addon ejecutado correctamente", xbmcgui.NOTIFICATION_INFO, 3000)
