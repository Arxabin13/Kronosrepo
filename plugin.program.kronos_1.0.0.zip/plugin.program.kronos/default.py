import xbmcgui
import xbmcaddon
import platform

addon = xbmcaddon.Addon()
dialog = xbmcgui.Dialog()

arch = platform.machine()
arch_map = {
    "aarch64": "Recomendado: Ajuste bajo (ARM64)",
    "armv7l": "Recomendado: Ajuste medio (ARMv7)",
    "x86_64": "Recomendado: Ajuste alto (x64)",
}

recommendation = arch_map.get(arch, "Arquitectura desconocida. Revisión manual recomendada.")
dialog.ok("Kronos", f"Dispositivo detectado: {arch}\n{recommendation}")
